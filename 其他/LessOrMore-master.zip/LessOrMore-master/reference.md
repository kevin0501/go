---
layout: post
title: 相关博客
permalink: /reference/
---

* content
{:toc}


走向架构师之路
=====================
[走向架构师之路](http://blog.csdn.net/cutesource/article/details/4901506)

HTTP协议详解
=====================
[HTTP协议详解](http://www.jmarshall.com/easy/http/)

Axis 2.0的入门
=====================
[曹胜欢][http://blog.csdn.net/csh624366188/article/details/8362696](http://blog.csdn.net/csh624366188/article/details/8362696)

[一线码农]
=====================
算法入门和分布式缓存入门
[http://www.cnblogs.com/huangxincheng/archive/2011/11/14/2249046.html](http://www.cnblogs.com/huangxincheng/archive/2011/11/14/2249046.html)

[雷霄骅]
=====================
视音频编解码技术学习方法
[http://blog.csdn.net/leixiaohua1020/article/details/18893769](http://blog.csdn.net/leixiaohua1020/article/details/18893769)

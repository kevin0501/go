---
layout: post
title: 打赏
header: 打赏
---

您的支持是作者写作最大的动力！
------------------------------
<hr>

如果您喜欢这个博客，读后觉得收获很大...

如果在你开发或学习过程中本博客帮助到了你...

你可以对本博客[小额赞助]({{ '/donate/method' | prepend: site.baseurl }})一下，让我有动力继续写出更高质量的文章。

点击上面小额赞助即可呦！
<br>

![Thank you very much!]({{ '/styles/images/freud.jpg' | prepend: site.baseurl }})
<br>

>声明: 此博客空间用于分享作者个人的一些技术相关， 此网站基于[MIT开源协议](https://github.com/luoyan35714/LessOrMore/blob/master/LICENSE)所有内容完全免费，请放心使用。

<hr>

赞助方式一：`支付宝二维码付款`
------------------------------

<hr>
您可以选择手机支付宝扫一扫

<img src="{{ '/styles/images/zhifubao.PNG' | prepend: site.baseurl }}" alt="支付宝二维码付款给Freud" width="310" />

<br>
<br>

赞助方式二：`微信扫一扫`
------------------------------

<hr>
您可以选择手机微信扫一扫

![微信二维码付款给Freud]({{ '/styles/images/weixin.png' | prepend: site.baseurl }})

<br>
<br>

<hr>

